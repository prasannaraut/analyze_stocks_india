__author__ = "Prasanna Raut (prasannaraut36@gmail.com)"
__version__ = "1.0.0"
__copyright__ = "Copyright (c) 2024 Prasanna Raut"
# Use of this source code is governed by the MIT license.
__license__ = "MIT"


from analyze_stocks_india.create_data_dir import  create_data_directory


create_data_directory()