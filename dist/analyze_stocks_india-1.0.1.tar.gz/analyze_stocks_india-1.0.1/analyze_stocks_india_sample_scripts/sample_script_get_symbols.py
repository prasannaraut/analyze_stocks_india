# this is a sample script to load nse symbols

from analyze_stocks_india.nse_symbols import nifty_50, nifty_100

print("Nifty 50 stocks are")
print(nifty_50)

print("Nifty 100 stocks are")
print(nifty_100)